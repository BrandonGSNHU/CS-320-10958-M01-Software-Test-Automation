import java.util.HashMap;
import java.util.Map;
// class for contact service
public class ContactService {
    private final Map<String, Contact> contacts = new HashMap<>();
// adding contact function
    public void addContact(Contact contact) {
        if (contacts.containsKey(contact.getContactId())) {
            throw new IllegalArgumentException("Contact ID already exists");
        }
        contacts.put(contact.getContactId(), contact);
    }
// deleting contacts
    public void deleteContact(String contactId) {
        contacts.remove(contactId);
    }
// updating contacts
    public void updateContact(String contactId, String firstName, String lastName, String phone, String address) {
        Contact contact = contacts.get(contactId);
        if (contact == null) {
            throw new IllegalArgumentException("Contact not found");
        }
        if (firstName != null) {
            contact.setFirstName(firstName);
        }
        if (lastName != null) {
            contact.setLastName(lastName);
        }
        if (phone != null) {
            contact.setPhone(phone);
        }
        if (address != null) {
            contact.setAddress(address);
        }
    }

    public Contact getContact(String contactId) {
        return contacts.get(contactId);
    }
}